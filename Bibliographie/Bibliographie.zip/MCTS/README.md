# MCTS

## MCTS for program synthesis

Le papier illustre l'utilisation de l'heuristique de recherche MCTS pour
synthétiser un programme.

La synthèse de programme a pour objectif de générer automatiquement un exécutable
d'un segment de code qui satisfait une specification.

## MCTS survey

Le papier expose une partie de la littérature sur la recherche MCTS.
Il liste une partie des cas d'utilisation du MCTS qui ont été satisfaisant
et non satisfaisant.

## MCTS path exploration symbolic execution

Proposition d'une stratégie pour donner la priorité à des chemins de valeurs
en utilisateur une méthode basée sur MCTS.
Ensuite la méthode utilisée est comparée aux autres méthodes:
- DFS: Parcours en profondeur
- BFS: Le meilleur d'abord (best first search)